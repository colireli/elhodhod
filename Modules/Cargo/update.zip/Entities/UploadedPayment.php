<?php

namespace Modules\Cargo\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UploadedPayment extends Model
{
    use HasFactory;
    protected $guarded = [];
}
