<?php

namespace Modules\Cargo\Http\Controllers;

use Modules\Cargo\Entities\PlanFee;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;

class PlanFeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PlanFee  $planFee
     * @return \Illuminate\Http\Response
     */
    public function show(PlanFee $planFee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PlanFee  $planFee
     * @return \Illuminate\Http\Response
     */
    public function edit(PlanFee $planFee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PlanFee  $planFee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PlanFee $planFee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PlanFee  $planFee
     * @return \Illuminate\Http\Response
     */
    public function destroy(PlanFee $planFee)
    {
        //
    }
}
