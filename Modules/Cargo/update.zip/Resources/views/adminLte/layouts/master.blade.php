<x-base-layout>

    <x-slot name="pageTitle">
        @yield('pageTitle')
    </x-slot>

    @yield('content')

</x-base-layout>